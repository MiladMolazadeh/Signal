function   Zaraieb_Seri_Furie_Cos(T,N0,N1)
syms t x
w0 = 2*pi/T;
n = N0:N1;
an = (1/T)*int(cos(x)*exp(-1j*n*w0*t),t,0,T)
end


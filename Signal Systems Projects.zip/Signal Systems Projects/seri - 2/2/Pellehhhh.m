function Pelleh(n0)
t = linspace(-10,10,21);
y = zeros(1,21);
y(n0+10:21) = 1;
stem(t,y);
ylim([-2,2]);
end

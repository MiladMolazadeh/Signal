function [output] = Zarbeh(inputArg1,inputArg2)

if(inputArg1 == inputArg2)
    output = 1;
    
else
   output = 0; 
end

end


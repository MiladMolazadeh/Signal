function Pelleh(n0,a1,a2)
n = linspace(a1,a2,abs(a1)+abs(a2)+1);
y = zeros(1,abs(a1)+abs(a2)+1);
y(abs(a1)+1+n0:abs(a1)+abs(a2)+1) = 1;
stem(n,y);
end

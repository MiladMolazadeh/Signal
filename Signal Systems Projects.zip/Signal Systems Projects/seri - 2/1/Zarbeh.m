function Zarbeh(n,a1,a2)
t = a1:1:a2;
y = zeros(1,abs(a1)+a2+1);
y(1,n+abs(a1)+1)=1;
stem(t,y);
ylim([-2,2]);
end


function [output] = Pelleh(n,n0)
if(n>=n0)
   output = 1;
else
    output = 0;
end
end
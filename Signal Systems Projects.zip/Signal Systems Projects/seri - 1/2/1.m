t = [0:.001:10];
a1=3*pi/2;
a2=pi/4;
a3=pi/2;

y1=cos(a1*t);
y2=cos(a2*t);
y3=cos(a3*t);

subplot(2,2,1);
plot(t,y1);
title 'cos(3*pi/2)'
subplot(2,2,2);
plot(t,y2);
title 'cos(pi/4)'
subplot(2,2,3);
plot(t,y3);
title 'cos(pi/2)'
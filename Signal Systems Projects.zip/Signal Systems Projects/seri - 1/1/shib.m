t=-10:1:10;
for i=1:11
c(i)=0;
end
for i=11:21
c(i)=i-11;
end
plot(t,c);

t=0:0.001:pi;
x=[.0181 .0543 .0543 .0181 ];
y=[1 -1.176 1.1829  -.278];
x=freqz(x,y,t);   %Frequency response of digital filter
stem(x)
subplot(2,2,2);
plot(t,abs(x))
subplot(2,2,1);
plot(t,angle(x))

t = [0:1:10];
a1=3*pi/2;
a2=pi/4;
a3=pi/2;

y1=cos(a1*t);
y2=cos(a2*t);
y3=cos(a3*t);

subplot(2,2,1);
stem(t,y1);
subplot(2,2,2);
stem(t,y2);
subplot(2,2,3);
stem(t,y2);
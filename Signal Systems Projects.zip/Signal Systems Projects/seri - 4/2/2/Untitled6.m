syms t
f_t = sin((2*pi*t/3) + (pi/4))/t;
ff = fourier(f_t,t);
ff
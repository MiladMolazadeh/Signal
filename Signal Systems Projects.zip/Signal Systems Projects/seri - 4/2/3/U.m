syms t
f_t = sin(pi*t/4)/t;
ff = fourier(f_t,t);
;ff
